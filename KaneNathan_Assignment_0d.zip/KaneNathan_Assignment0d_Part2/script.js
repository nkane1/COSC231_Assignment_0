var body = document.body;

var container = document.createElement('div');
container.id= 'content-container';
body.appendChild(container);

var h1 = document.createElement('h1');
h1.innerHTML='Nathan Kane';
h1.className='green';
container.appendChild(h1);

var h4_1 = document.createElement('h4');
h4_1.innerHTML="The World's Most Amazing Person";
h4_1.className='purple';
container.appendChild(h4_1);

var upperHalf = document.createElement('div');
upperHalf.id= 'image_withText';
container.appendChild(upperHalf);

var image = document.createElement('img');
image.src= 'http://people.emich.edu/abradl26/images/my_row.jpg';
upperHalf.appendChild(image);

var p1 = document.createElement('p');
p1.id= 'aboutMe';
p1.innerHTML = 'My name is Nathan Kane. I am a Mathematics major and \
Computer Science and Japanese dual-minor. This is mythird year at EMU and \
my second year learning on programming. I grew up in an Army family and due\
 to that, spent five years living in Pyeongtaek, ROK. I am certainly <em>NEVER</em> \
 sarcastic, so one <em>DEFINITELY</em> has no need to watch out for that \
 while talking to me. I\'m the guy on the right by the way.';
upperHalf.appendChild(p1);

var bottomHalf = document.createElement('div');
bottomHalf.id= 'hereAndBelow';
container.appendChild(bottomHalf);

var break1 = document.createElement('hr');
bottomHalf.appendChild(break1);

var p2 = document.createElement('p');
bottomHalf.appendChild(p2);

var link1 = document.createElement('a');
link1.target= '_blank';
link1.href= 'https://github.com/pegurnee-edu';
link1.innerHTML= 'Here';
p2.appendChild(link1);

var content = document.createTextNode(' is the link for class content.');
p2.appendChild(content);

var break2 = document.createElement('hr');
bottomHalf.appendChild(break2);
	
var schedule = document.createElement('table');
bottomHalf.appendChild(schedule);

var tr1 = document.createElement('tr');
tr1.id= 'odd-row';
schedule.appendChild(tr1);
	
var th1_1 = document.createElement('th');
th1_1.innerHTML= 'Course Name';
tr1.appendChild(th1_1);

var th1_2 = document.createElement('th');
th1_2.innerHTML= 'CRN';
tr1.appendChild(th1_2);

var th1_3 = document.createElement('th');
th1_3.innerHTML= 'Days Meeting';
tr1.appendChild(th1_3);

var th1_4 = document.createElement('th');
th1_4.innerHTML= 'Time Start';
tr1.appendChild(th1_4);

var th1_5 = document.createElement('th');
th1_5.innerHTML= 'Time Finish';
tr1.appendChild(th1_5);

var th1_6 = document.createElement('th');
th1_6.innerHTML= 'Instructor Name';
tr1.appendChild(th1_6);

var th1_7 = document.createElement('th');
th1_7.innerHTML= 'Room Number';
tr1.appendChild(th1_7);

var tr2 = document.createElement('tr');
tr2.id= 'even-row';
schedule.appendChild(tr2);
	
var th2_1 = document.createElement('th');
tr2.appendChild(th2_1);
			
var link2 = document.createElement('a');
link2.href= 'http://kimrescorla.weebly.com/';
link2.innerHTML= 'MATH 223';
th2_1.appendChild(link2);
		
var th2_2 = document.createElement('th');
th2_2.innerHTML= '11376';
tr2.appendChild(th2_2);

var th2_3 = document.createElement('th');
th2_3.innerHTML= 'MWRF';
tr2.appendChild(th2_3);

var th2_4 = document.createElement('th');
th2_4.innerHTML= '0930';
tr2.appendChild(th2_4);

var th2_5 = document.createElement('th');
th2_5.innerHTML= '1020';
tr2.appendChild(th2_5);

var th2_6 = document.createElement('th');
th2_6.innerHTML= 'Kim Rescorla';
tr2.appendChild(th2_6);

var th2_7 = document.createElement('th');
th2_7.innerHTML= 'Pray-H 323';
tr2.appendChild(th2_7);

var tr3 = document.createElement('tr');
tr3.id= 'odd-row';
schedule.appendChild(tr3);
	
var th3_1 = document.createElement('th');
th3_1.innerHTML= 'MATH 211';
tr3.appendChild(th3_1);

var th3_2 = document.createElement('th');
th3_2.innerHTML= '11374';
tr3.appendChild(th3_2);

var th3_3 = document.createElement('th');
th3_3.innerHTML= 'MW';
tr3.appendChild(th3_3);

var th3_4 = document.createElement('th');
th3_4.innerHTML= '1100';
tr3.appendChild(th3_4);

var th3_5 = document.createElement('th');
th3_5.innerHTML= '1215';
tr3.appendChild(th3_5);

var th3_6 = document.createElement('th');
th3_6.innerHTML= 'Gisela Ahlbrandt';
tr3.appendChild(th3_6);

var th3_7 = document.createElement('th');
th3_7.innerHTML= 'Pray-H 405';
tr3.appendChild(th3_7);
		
var tr4 = document.createElement('tr');
tr4.id= 'even-row';
schedule.appendChild(tr4);
	
var th4_1 = document.createElement('th');
th4_1.innerHTML= 'COSC 211';
tr4.appendChild(th4_1);

var th4_2 = document.createElement('th');
th4_2.innerHTML= '13988';
tr4.appendChild(th4_2);

var th4_3 = document.createElement('th');
th4_3.innerHTML= 'TR';
tr4.appendChild(th4_3);

var th4_4 = document.createElement('th');
th4_4.innerHTML= '1200';
tr4.appendChild(th4_4);

var th4_5 = document.createElement('th');
th4_5.innerHTML= '1350';
tr4.appendChild(th4_5);

var th4_6 = document.createElement('th');
th4_6.innerHTML= 'Aby Tehranipour';
tr4.appendChild(th4_6);

var th4_7 = document.createElement('th');
th4_7.innerHTML= 'Pray-H 520';
tr4.appendChild(th4_7);
	
var tr5 = document.createElement('tr');
tr5.id= 'odd-row';
schedule.appendChild(tr5);
	
var th5_1 = document.createElement('th');
tr5.appendChild(th5_1);
			
var link3 = document.createElement('a');
link3.href= '231/';
link3.innerHTML= 'COSC 231';
th5_1.appendChild(link3);
		
var th5_2 = document.createElement('th');
th5_2.innerHTML= '12302';
tr5.appendChild(th5_2);

var th5_3 = document.createElement('th');
th5_3.innerHTML= 'TR';
tr5.appendChild(th5_3);

var th5_4 = document.createElement('th');
th5_4.innerHTML= '1400';
tr5.appendChild(th5_4);

var th5_5 = document.createElement('th');
th5_5.innerHTML= '1550';
tr5.appendChild(th5_5);

var th5_6 = document.createElement('th');
th5_6.innerHTML= 'Edward Gurnee';
tr5.appendChild(th5_6);

var th5_7 = document.createElement('th');
th5_7.innerHTML= 'Pray-H 514';
tr5.appendChild(th5_7);
		
var tr6 = document.createElement('tr');
tr6.id= 'even-row';
schedule.appendChild(tr6);
	
var th6_1 = document.createElement('th');
th6_1.innerHTML= 'JPNE 211L5';
tr6.appendChild(th6_1);

var th6_2 = document.createElement('th');
th6_2.innerHTML= '17174';
tr6.appendChild(th6_2);

var th6_3 = document.createElement('th');
th6_3.innerHTML= 'MTR';
tr6.appendChild(th6_3);

var th6_4 = document.createElement('th');
th6_4.innerHTML= '1730';
tr6.appendChild(th6_4);

var th6_5 = document.createElement('th');
th6_5.innerHTML= '1900';
tr6.appendChild(th6_5);

var th6_6 = document.createElement('th');
th6_6.innerHTML= 'Konomi Corbin';
tr6.appendChild(th6_6);

var th6_7 = document.createElement('th');
th6_7.innerHTML= 'Alexander 206';
tr6.appendChild(th6_7);
	
var tr7 = document.createElement('tr');
tr7.id= 'odd-row';
schedule.appendChild(tr7);

var th7_1 = document.createElement('th');
th7_1.innerHTML= 'COSC 212';
tr7.appendChild(th7_1);

var th7_2 = document.createElement('th');
th7_2.innerHTML= '17349';
tr7.appendChild(th7_2);

var th7_3 = document.createElement('th');
th7_3.innerHTML= 'N/A';
tr7.appendChild(th7_3);

var th7_4 = document.createElement('th');
th7_4.innerHTML= 'N/A';
tr7.appendChild(th7_4);

var th7_5 = document.createElement('th');
th7_5.innerHTML= 'N/A';
tr7.appendChild(th7_5);

var th7_6 = document.createElement('th');
th7_6.innerHTML= 'Augustine Ikeji';
tr7.appendChild(th7_6);

var th7_7 = document.createElement('th');
th7_7.innerHTML= 'ONLINE';
tr7.appendChild(th7_7);

var break3 = document.createElement('hr');
bottomHalf.appendChild(break3);

var pokemon = document.createElement('div');
pokemon.id= 'pokemon';
bottomHalf.appendChild(pokemon);

var h4_2 = document.createElement('h4');
h4_2.className= 'purple';
h4_2.innerHTML= 'My Top 4 Pokemon';
pokemon.appendChild(h4_2);

var tops = document.createElement('ol');
pokemon.appendChild(tops);
	
var li1 = document.createElement('li');
tops.appendChild(li1);
	
var link4 = document.createElement('a');
link4.target= '_blank';
link4.href= 'http://bulbapedia.bulbagarden.net/wiki/Rayquaza_%28Pok%C3%A9mon%29';
link4.innerHTML= 'Rayquaza';
li1.appendChild(link4);
		
var li2 = document.createElement('li');
tops.appendChild(li2);
		
var link5 = document.createElement('a');
link5.target= '_blank';
link5.href= 'http://bulbapedia.bulbagarden.net/wiki/File:006Charizard-Mega_X.png';
link5.innerHTML= 'Mega Charizard X';
li2.appendChild(link5);
			
var li3 = document.createElement('li');
tops.appendChild(li3);
		
var link6 = document.createElement('a');
link6.target= '_blank';
link6.href= 'http://bulbapedia.bulbagarden.net/wiki/Mew_%28Pok%C3%A9mon%29';
link6.innerHTML= 'Mew';
li3.appendChild(link6);

var li4 = document.createElement('li');
tops.appendChild(li4);
		
var link7 = document.createElement('a');
link7.target= '_blank';
link7.href= 'http://bulbapedia.bulbagarden.net/wiki/Totodile_%28Pok%C3%A9mon%29';
link7.innerHTML= 'Totadile';
li4.appendChild(link7); 
			
			
			
			
			
			